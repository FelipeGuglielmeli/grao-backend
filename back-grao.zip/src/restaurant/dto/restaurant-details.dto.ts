export class AddressDto {
    street: string;
    city: string;
    number: string;
    neighborhood: string;
}

export class RestaurantDetailsDto {
    name: string;
    averageRating: number;
    phone: string;
    address: AddressDto;
}
