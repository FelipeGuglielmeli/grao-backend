import { Injectable, UnauthorizedException, InternalServerErrorException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UserService } from '../user/user.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    private readonly userService: UserService,
    private readonly jwtService: JwtService,
  ) {}

  async validateUser(email: string, password: string): Promise<any> {
    try {
      console.log('Iniciando validação de usuário:', email);

      const user = await this.userService.findByEmail(email);

      if (!user) {
        console.log('Usuário não encontrado:', email);
        throw new UnauthorizedException('Credenciais inválidas: email não encontrado.');
      }

      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        console.log('Senha incorreta para o email:', email);
        throw new UnauthorizedException('Credenciais inválidas: senha incorreta.');
      }

      console.log('Usuário validado com sucesso:', user);
      const { password: userPassword, ...result } = user;
      return result;

    } catch (error) {
      console.error('Erro na validação de usuário:', error.message);
      throw error;
    }
  }

  async login(user: any) {
    try {
      console.log('Iniciando processo de login para o usuário:', user.email);

      const payload = { email: user.email, sub: user.id };

      const token = this.jwtService.sign(payload);
      console.log('Token JWT gerado:', token);

      return {
        accessToken: token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          isActive: user.isActive,
        },
      };
    } catch (error) {
      console.error('Erro ao gerar o token JWT:', error.message);
      throw new InternalServerErrorException('Erro ao fazer login.');
    }
  }
}
