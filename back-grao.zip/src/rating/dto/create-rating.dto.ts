export class CreateRatingDto {
    restaurantId: number;
    userId: number;
    rating: number;
    comment: string;
  }
  